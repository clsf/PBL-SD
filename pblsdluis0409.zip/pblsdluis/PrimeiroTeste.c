#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

/*char* comunicacao(){
    char botao [255];
    printf("Desligar / Ligar o led? [l/d]");
    scanf("%s", botao);
    return botao;
}*/

void printBinary(unsigned char byte){
	for (int i = 7; i >= 0; i--) {
		printf("%d", (byte>>i) & 1);
	}
}

int main(){

    int fd, len, len2, len3, len4;
    char valor[255];
    char valor2[255];
    char valor3[255];
    char valor4[255];
    struct termios options;

    /*Abre a porta
        as flags: O_RDWR para ler e escrever
        O_NDELAY: Chamada retorna imediatamente, mesmo que sem dados
        O_NOCTTy ??
    */
    fd = open("/dev/ttyS0", O_RDWR | O_NDELAY | O_NOCTTY );
    if(fd<0){
    	printf("erro");
        return -1;
    }

    //Para ler as configura��es da porta atual:
    //tcgetattr(fd, &options);

    /*A sigla "c_cflag" significa "control flag" ou "conjunto de flags de controle".
      B9600 ? velocidade?
      CS8 - usa 8 bits
    */
   options.c_cflag = B9600 | CS8 | CLOCAL| CREAD;
   //cfsetspeed(&options, B9600);

   //input flags
   options.c_iflag  = IGNPAR;
   //output flags
   options.c_oflag =0;
   options.c_lflag =0;

   //limpa a entrada do buffer
   tcflush(fd, TCIFLUSH);
   //Aplica as configura��es
   tcsetattr(fd, TCSANOW, &options);
   
/*
   strcpy(valor, "1");
   len = strlen(valor);
   printf("Len: %d\n", len);
   
   len = write(fd, valor, len);
   printf(" Enviei:  %d \n", len);
   sleep(5);*/

  while(1){
  
  	// ESCRITA 1
  
 printf("n1: ");
    scanf("%s", valor);
    len = strlen(valor);
   printf("Len: %d\n", len);
   
   unsigned char *ptr = valor;
   for (int i = 0; i < sizeof(char); i++) {
   	printf("Byte %d: ", i+1);
   	printBinary(ptr[i]);
   	printf("\n");
   }
   
   len = write(fd, valor, len);
   printf(" Enviei:  %d \n", len);
    
    printf("%d", len);
    
    sleep(0.5);
    
    // ESCRITA 2
    
     printf("n2:");
    scanf("%s", valor3);
    len3 = strlen(valor3);
   printf("Len3: %d\n", len3);
   
   unsigned char *ptr3 = valor3;
   for (int i = 0; i < sizeof(char); i++) {
   	printf("Byte %d: ", i+1);
   	printBinary(ptr3[i]);
   	printf("\n");
   }
   
   len3 = write(fd, valor3, len3);
   printf(" Enviei:  %d \n", len3);
    
    printf("%d", len3);
    
    
    sleep(0.5);

	// LEITURA 1

    memset(valor2, 0, 255);
    len2 = read(fd, valor2, 255);
    
    unsigned char *ptr2 = valor2;
   for (int i = 0; i < sizeof(char); i++) {
   	printf("Byte %d: ", i+1);
   	printBinary(ptr2[i]);
   	printf("\n");
   }
   
    printf("Received %d bytes\n", len2);
    printf("Received string: %s\n", valor2);
    
    sleep(0.5);
    // LEITURA 2
     memset(valor4, 0, 255);
    len4 = read(fd, valor4, 255);
    
    unsigned char *ptr4 = valor4;
   for (int i = 0; i < sizeof(char); i++) {
   	printf("Byte %d: ", i+1);
   	printBinary(ptr4[i]);
   	printf("\n");
   }
   
    printf("Received %d bytes\n", len4);
    printf("Received string: %s\n", valor4);
    
    }
   close(fd);
}
